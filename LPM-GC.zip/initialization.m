run('.\vlfeat-0.9.21-bin\vlfeat-0.9.21\toolbox\vl_setup.m');
vl_version
